package br.com.kasolution.exemplo;

public class Teste01 {

    public static void main(String[] args) {
        int idade;
        idade = 17;
        System.out.println("O valor de idade é: " + idade);
        idade = 42;
        System.out.println("O valor de idade é: " + idade);

    }
}
