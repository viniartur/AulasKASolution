
package br.com.kasolution.exemplo;


public class Teste04 {

  
    public static void main(String[] args) {
      String frase = "Esta uma frase armazenada e uma String";
        System.out.println(frase);
        frase = frase + "!";
        System.out.println(frase);
    }
}
