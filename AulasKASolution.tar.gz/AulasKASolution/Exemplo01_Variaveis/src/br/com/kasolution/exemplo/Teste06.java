
package br.com.kasolution.exemplo;


public class Teste06 {

    
    public static void main(String[] args) {
        System.out.println("Acumular valor");
        int v1 = 10;
        v1 = v1 + 30; // v1 += v1 + 30;
        System.out.println("Valor acumulado: "+v1);
        System.out.println("Contador: ");
        int c1 = 0;
        c1 ++;
        System.out.println("Valor contado: "+c1);
    }
}
