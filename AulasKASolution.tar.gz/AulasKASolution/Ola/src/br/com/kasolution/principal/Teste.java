package br.com.kasolution.principal;


public class Teste {

   
    public static void main(String[] args) {
        System.out.println("Este é um teste do programador");
    }
}
