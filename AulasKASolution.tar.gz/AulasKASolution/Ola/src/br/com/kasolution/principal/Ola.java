package br.com.kasolution.principal;


import sun.applet.Main;

/* 
 * criado por vinicius 
 * aula java 30/10/2018
 */
public class Ola {

    public static void main(String[] args) {
        System.out.println("Olá Java!");
    }
}
