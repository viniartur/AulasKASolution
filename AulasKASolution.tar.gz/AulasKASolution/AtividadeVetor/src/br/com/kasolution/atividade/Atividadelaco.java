package br.com.kasolution.atividade;

public class Atividadelaco {

    public static void main(String[] args) {
        int n[] = new int[20];

        n[0] = 1;
        n[1] = 2;
        n[2] = 3;
        n[3] = 4;
        n[4] = 5;
        n[5] = 6;
        n[6] = 7;
        n[7] = 8;
        n[8] = 9;
        n[9] = 10;
        n[10] = 11;
        n[11] = 12;
        n[12] = 13;
        n[13] = 14;
        n[14] = 15;
        n[15] = 16;
        n[16] = 17;
        n[17] = 18;
        n[18] = 19;
        n[19] = 20;


        for (int i : n) {
            if (i % 2 != 0) {
                System.out.println(i);

            }
            if (i >= 15) {
                break;
            }
        }
        System.out.println("Saiu do laço");
    }
}