
package br.com.kasolution.atividade;


public class Atividade1 {
 
    public static void main(String[] args) {
         String[]m = new String[12];
    m[0] = "Janeiro";
    m[1] = "fevereiro";
    m[2] = "marco";
    m[3] = "abril";
    m[4] = "maio";
    m[5] = "Janho";
    m[6] = "Julho";
    m[7] = "Agosto";
    m[8] = "Setembro";
    m[9] = "Outubro";
    m[10] = "Novembro";
    m[11] = "Dezembro";
    
   for (String i : m){
       System.out.println(i);
        
    }
       
        
    }
}
