
package br.com.kasolution.teste;

import br.com.kasolution.dominio.EmpregadoBase;
import br.com.kasolution.dominio.EmpregadoComissionado;


public class TesteEmpregado01 {

    
    public static void main(String[] args) {
        EmpregadoBase eb = new EmpregadoBase("Igor", "Ribeiro", "055.456.072-35");
        System.out.println(eb.imprime());
        EmpregadoComissionado ec = new EmpregadoComissionado("Emilia","Fico","431.581.400-80", 15000.00,0.1);
        System.out.println(ec.imprime());
    }
    
}
