package br.com.kasolution.dominio;

public class EmpregadoComissionado extends EmpregadoBase {

    private double vendaBruta;
    private double porcentagemComissao;

    public EmpregadoComissionado() {

    }

    public EmpregadoComissionado(String nome, String sobrenome, String cpf, double vendaBruta, double porcetagemComissao) {
        super(nome, sobrenome, cpf);
        this.vendaBruta = vendaBruta;
        this.porcentagemComissao = porcetagemComissao;
    }

    public double getVendaBruta() {
        return vendaBruta;
    }

    public void setVendaBruta(double vendaBruta) {
        this.vendaBruta = vendaBruta;
    }

    public double getPorcentagemComissao() {
        return porcentagemComissao;
    }

    public void setPorcentagemComissao(double porcentagemComissao) {
        this.porcentagemComissao = porcentagemComissao;
    }

    public EmpregadoComissionado(double vendaBruta, double porcentagemComissao) {
        this.vendaBruta = vendaBruta;
        this.porcentagemComissao = porcentagemComissao;
    }

    @Override
    public String imprime() {
//        String info = "Nme:" + getNome() + "\n";
//        info += "sobrenome: "+ getSobrenome() + "\n";
//        info +="cpf: " + getCpf() + "\n";
        String info = super.imprime();
        info += "Venda Bruta: " + vendaBruta + "\n";
        info += "Comissão: " + porcentagemComissao + "\n";
        return info;

    }
}
