/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

/**
 *
 * @author Admin
 */
public class AfirmacaoTeste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int x = 10;
        
        if (x > 10) {
           System.out.println("É maior que 10");
        } else {
            assert false : x > 10;
            System.out.println("É menor que 10");
        }
    }
}
