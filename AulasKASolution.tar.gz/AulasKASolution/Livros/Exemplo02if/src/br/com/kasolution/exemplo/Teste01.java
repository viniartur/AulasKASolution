package br.com.kasolution.exemplo;

import java.util.Scanner;

public class Teste01 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int idade = sc.nextInt();
        System.out.print("A sua idade é: "+ idade);
        if (idade >= 16){
            System.out.println("Voce pode tirar o titulo ");
        }else{ 
            System.out.println(" Espere fazer 16 para tirar o titulo");
        
        }
    }
}
