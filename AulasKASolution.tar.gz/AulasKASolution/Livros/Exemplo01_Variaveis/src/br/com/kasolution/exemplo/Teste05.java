package br.com.kasolution.exemplo;

public class Teste05 {

    public static void main(String[] args) {
        System.out.println("Curiosidade String: ");
        String v1 = "2", v2 = "5";
        String r1 = v1 + v2;
        System.out.println("Resultado " + r1);
        System.out.println("Curiosidade double/int " + r1);
        int i1 = 9, i2 = 2;
        double r2 = i1 / i2;
        System.out.println("Resultados: " + r2);
//        int i1 = 9;
        //double i2 = 2;
//        double r2 = i1/i2;
//        System.out.println("Resultados: " + r2);
          r2 = 7/2.0;
        System.out.println("Resultados: " + r2);

    }
    
}
