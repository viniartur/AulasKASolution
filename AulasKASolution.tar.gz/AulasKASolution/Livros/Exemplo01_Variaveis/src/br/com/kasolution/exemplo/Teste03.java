package br.com.kasolution.exemplo;

public class Teste03 {

    public static void main(String[] args) {

        double resultado = 0;
        resultado = 25 - 5 * 4 / 2 - 10 + 4;
        System.out.println("Resultado: " + resultado);
        resultado = 25 - 5 * (4 / ((2 - 10) + 4));
        System.out.println("Resultado: " + resultado);

    }
}
