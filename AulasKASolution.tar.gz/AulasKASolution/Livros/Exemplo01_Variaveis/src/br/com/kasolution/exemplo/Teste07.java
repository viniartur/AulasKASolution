package br.com.kasolution.exemplo;

public class Teste07 {

    public static void main(String[] args) {
        int c1 = 10;
        int c2 = c1++;
        int c3 = 12;
        int c4 = ++c3;
        System.out.println("C1: " + c1);
        System.out.println("C2: " + c2);
        System.out.println("C3: " + c3);
        System.out.println("C3: " + c4);





    }
}
