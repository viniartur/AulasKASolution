package br.com.kasolution.exemplo;

public class Teste2 {

    public static void main(String[] args) {
        int valor1 = 10, valor2 = 5;
        int resultado = valor1 + valor2;
        System.out.println("A soma de valor1 e valor2 é: " + resultado);
        resultado = valor1 * valor2;
        System.out.println("A divisão de valor1 e valor2 é: " + resultado);
        resultado = valor1 - valor2;
        System.out.println("A subtração de valor1 e valor2 é: " + resultado);
        resultado = valor1 / valor2;
        System.out.println("A divisão de valor1 e valor2 é: " + resultado);

    }
}
