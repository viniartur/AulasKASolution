package br.com.kasolution.teste;

import br.com.kasolution.dominio.Livro;
import br.com.kasolution.dominio.Prateleira;

public class TestePrateleira {

    public static void main(String[] args) {

        Livro[] livros = {
            new Livro("Java avaçado", "Técnico"),
            new Livro("Java Basico", "Técnico"),
            new Livro("Java OCA/OCP", "Técnico"),
            new Livro("Android", "Técnico"),
            new Livro("Spring MVC", "Técnico"),
            new Livro("Josgos Java", "Técnico"),
            new Livro("Jboss", "Técnico"),
            new Livro("GlassFish", "Técnico"),
            new Livro("Oracle Java", "Técnico"),
            new Livro("Java web", "Técnico"),
            new Livro("Angular JS", "Técnico"),
            new Livro("Jquery", "Técnico")
        };// fim vetor
        Prateleira prateleira = new Prateleira(3, 4);
        prateleira.organizaLivros(livros);
        prateleira.imprime();
        System.out.println("\n busca livro");
        prateleira.buscaLivro("MVC");
        
    }
    

}
