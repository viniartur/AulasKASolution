package br.com.kasolution.dominio;

public class Prateleira {

    private int linhas;
    private int colunas;
    private Livro[][] prateleira;

    public Prateleira(int linhas, int colunas) {
        this.linhas = linhas;
        this.colunas = colunas;
        this.prateleira = new Livro[linhas][colunas];
    }

    public void organizaLivros(Livro[] livros) {
        int totalDeLivros = linhas * colunas;
        if (livros.length <= totalDeLivros) {
            int l = 0;
            for (int i = 0; i < linhas; i++) {
                for (int j = 0; j < colunas; j++) {
                    this.prateleira[i][j] = livros[l++];

                } // end for j
            }// end for i
        }//end if
        else {
            System.out.println("Quantidade de livros não suportada");
        }//end else
    }

    public void imprime() {
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print("["+this.prateleira[i][j]+"]");

            } // colunas
            System.out.println();
        }// fim linhas
    }// fim imprime
    public void buscaLivro(String nome) {
    for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                //if (prateleira[i][j].getNome().equals(nome)){
                if (prateleira[i][j].getNome().contains(nome)){
                    System.out.println("livro Encontrato na posição: L["+ i +"]"+"["+ j + "]");  
                    return; // sai imediatamente
                }
                System.out.print("["+this.prateleira[i][j]+"]");

            } // colunas
            System.out.println();
        }// fim linhas
        System.out.println("Livro não encontrado !");
}
}//fim classe
