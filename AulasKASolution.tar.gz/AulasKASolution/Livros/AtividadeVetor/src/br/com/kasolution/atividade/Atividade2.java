
package br.com.kasolution.atividade;


public class Atividade2 {

    
    public static void main(String[] args) {
        String[] meses = {"jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez"};
        
        for (String mes : meses){
        System.out.println(mes);
    }
       
    }
}
