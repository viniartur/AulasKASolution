package br.com.kasolution.atividade;

import org.omg.CORBA.DATA_CONVERSION;

public class Atividade4 {

    public static void main(String[] args) {
        int n[] = new int[20];
         

        n[0] = 1;
        n[1] = 2;
        n[2] = 3;
        n[3] = 4;
        n[4] = 5;
        n[5] = 6;
        n[6] = 7;
        n[7] = 8;
        n[8] = 9;
        n[9] = 10;
        n[10] = 11;
        n[11] = 12;
        n[12] = 13;
        n[13] = 14;
        n[14] = 15;
        n[15] = 16;
        n[16] = 17;
        n[17] = 18;
        n[18] = 19;
        n[19] = 20;
        System.out.println("Total " + n.length);

        for (int i : n) {
            if (i % 5 != 0){
            continue;
        }
                System.out.println(i);

            

        }
    }
}

