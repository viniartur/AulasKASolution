package br.com.kasolution.teste;

import br.com.kasolution.modelo.Aluno;
import javax.sound.midi.Soundbank;

public class TesteAluno1 {

    public static void main(String[] args) {
        Aluno a1 = new Aluno(1, "Flávio dantas");
        a1.notas = new double[]{7.5, 9.6, 8.0, 7.7};
        Aluno a2 = new Aluno(2, "Kelvin odrigues");
        a2.notas = new double[]{5.0, 5.0, 5.0, 5.0};
        a1.notaCorte = 7.0;
        a2.notaCorte = 5.0;
        Aluno.notaCorte = 0.9;
        a1.imprimir();
        System.out.println("\n");
        a2.imprimir();
        System.out.println("a1: " + a1.notaCorte);
        System.out.println("a2: " + a2.notaCorte);
    }// fim main
}
