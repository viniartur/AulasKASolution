/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.kasolution.modelo;

import br.com.kasolution.util.Formata;

/**
 *
 * @author Admin
 */
public class Aluno {

    public int codigo;
    public String nome;
    public double[] notas;
    public static double notaCorte;

    public Aluno(int codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;


    }

    public double calculaMedia() {
        double total = 0;
        for (double n : notas) {
            total += n;
        }// fim for
        return total / notas.length;
    }//fim calcula

    public String verificaAprocacao() {
        double media = calculaMedia();
        if (media >= notaCorte) {
            return "aprovado";
        } else {
            return "reprovado";
        }// fim if 

    }//verifica

    public void imprimir() {
        System.out.println("Aluno: " + codigo);
        System.out.println("Nome: " + nome);
        System.out.println("Notas: ");
        System.out.println("\t");
        for (double n : notas) {
            System.out.println(Formata.num(n) + " ");
        }//fimfor
        System.out.println("Média: " + Formata.num(calculaMedia()));
        System.out.println("Situação: " + verificaAprocacao());

    }
}// fim classe
