/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.domain;

import java.text.NumberFormat;

/**
 *
 * @author Admin
 */
public class Director extends Manager {
    
    private double budget;
    
    public Director(int iD, String name, String sSN,
            double salary, String deptName, double budget) {
        super(iD, name, sSN, salary, deptName);
        this.budget = budget;
    }
    
    public double getBudget() {
        return this.budget;
    }
    
    @Override
    public String toString() {
        return super.toString() + 
                "\nEmployee Budget: "
                + NumberFormat.getCurrencyInstance().format(getBudget());
    }
    
    
    
}
