/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import com.example.business.EmployeeStockPlan;
import com.example.domain.Admin;
import com.example.domain.Director;
import com.example.domain.Employee;
import com.example.domain.Engineer;
import com.example.domain.Manager;
import java.text.NumberFormat;

/**
 *
 * @author Admin
 */
public class EmployeeTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Employee emp = new Engineer(101, "Jane Smith",
                "012-34-5678", 120_345.27);
        Employee mgr = new Manager(207, "Barbara Jonhson",
                "054-12-2367", 109_501.36, "US Marketing");
        Employee adm = new Admin(304, "Bill Monroe",
                "108-23-6509", 75_002.34);
        Employee drt = new Director(12, "Susan Wheeler",
                "099-45-2340", 120_567.36, "Global Marketing",
                1_000_000.00);
        drt.setName(drt.getName() + " Silva");
        drt.raiseSalary(1_000);
        
        EmployeeStockPlan esp = new EmployeeStockPlan();
        printEmployee(emp, esp);
        printEmployee(mgr, esp);
        printEmployee(adm, esp);
        printEmployee(drt, esp);
        
        ((Manager)mgr).addEmployee(emp);
        ((Manager)mgr).addEmployee(adm);
        ((Manager)mgr).addEmployee(drt);
        ((Manager)mgr).printStaffDetails();
        //Teste repetidos
        ((Manager)mgr).addEmployee(adm);
        ((Manager)mgr).addEmployee(adm);
        ((Manager)mgr).addEmployee(adm);
        //Teste remover
        ((Manager)mgr).removeEmployee(drt);
        ((Manager)mgr).printStaffDetails();      
        
    }
    
    public static void printEmployee(Employee emp) {
        System.out.print("\nEmployee type: " + 
                emp.getClass().getSimpleName());
        System.out.println(emp);
    }
    
    public static void printEmployee(Employee emp,
            EmployeeStockPlan esp) {
        printEmployee(emp);
        System.out.println("Stock Options:"
                + esp.grantStock(emp));
    }
}
