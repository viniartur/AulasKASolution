
import java.util.ArrayList;
import java.util.List;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class TesteLista {
    
    List<Roupa> camisas = new ArrayList<>();
    
    public static void main (String...args) {
    }
    
}
