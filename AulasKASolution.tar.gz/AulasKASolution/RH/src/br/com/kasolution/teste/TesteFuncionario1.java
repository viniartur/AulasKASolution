
package br.com.kasolution.teste;

import br.com.kasolution.dominio.Funcionario;


public class TesteFuncionario1 {

    public static void main(String[] args) {
        Funcionario f1 = new Funcionario("Emilia", "Fico", 35000.00);
        Funcionario f2 = new Funcionario("Hussein", "Khali", -60000.00);
       // Funcionario.ultimoCodigo = 1;
        Funcionario f3 = new Funcionario("Vinicius", "Vieira");
        f3.setSalario(-70000.00); 
        System.out.println(f1.imprime());
        System.out.println(f2.imprime());
        System.out.println(f3.imprime());
        f3.setSalario(10000.00);
        System.out.println("Novo salario do Vinicius " + f3.getSalario());
        
    }
}
