package br.com.kasolution.teste;

import br.com.kasolution.dominio.Funcionario;
import br.com.kasolution.util.Util;
import java.time.LocalDate;
import java.time.Month;

public class TesteFuncionario2 {

    public static void main(String[] args) {
        Funcionario f = new Funcionario("Renato", "fillippelli", 20000.00);
        //data do dia 

        f.setDataNascimento(LocalDate.of(1995, 3, 20));
        System.out.println(f.imprime());
        System.out.println("Mês aniversario " + f.getNome()+":");
        Util.fazTraco(30);
        System.out.println(Util.getMesAniversario2(f));
        System.out.println("Meses até o teto salarial: "+ Util.getMesesTetoSalario2(f));
        Util.fazTraco(30);

    }

}
