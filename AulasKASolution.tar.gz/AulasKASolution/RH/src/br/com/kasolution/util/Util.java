package br.com.kasolution.util;

import br.com.kasolution.dominio.Funcionario;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class Util {

    public static final double TETO_SALARIAL = 50000.00;

    public static String fData(LocalDate data) {
        return data.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM));

    }

    public static String getMesAniversario(Funcionario f) {
        int mes = f.getDataNascimento().getMonthValue();
        if (mes == 1) {
            return "janeiro";

        } else if (mes == 2) {
            return "fevereiro";
        } else if (mes == 3) {
            return "Março";
        } else if (mes == 4) {
            return "Abril";
        } else if (mes == 5) {
            return "Maio";
        } else if (mes == 6) {
            return "Junho";
        } else if (mes == 7) {
            return "Julho";
        } else if (mes == 8) {
            return "Agosto";
        } else if (mes == 9) {
            return "Setembro";
        } else if (mes == 10) {
            return "Outubro";
        } else if (mes == 11) {
            return "Novembro";
        } else {
            return "Dezembro";
        }

    }

    public static String getMesAniversario2(Funcionario f) {
        int mes = f.getDataNascimento().getMonthValue();
        String nomeMes;
        switch (mes) {
            case 1:
                nomeMes = "janeiro";
                break;
            case 2:
                nomeMes = "fevereiro";
                break;
            case 3:
                nomeMes = "Março";
                break;
            case 4:
                nomeMes = "Abril";
                break;
            case 5:
                nomeMes = "Maio";
                break;
            case 6:
                nomeMes = "Junho";
                break;
            case 7:
                nomeMes = "Julho";
                break;
            case 8:
                nomeMes = "Agosto";
                break;
            case 9:
                nomeMes = "Setembro";
                break;
            case 10:
                nomeMes = "Outubro";
                break;
            case 11:
                nomeMes = "Novembro";
                break;
            default:
                nomeMes = "Dezembro";
                break;
        }
        return nomeMes;
    }

    public static int getMesesTetoSalario(Funcionario f) {
        double salarioInicial = f.getSalario();
        int c = 0;
        while (salarioInicial < TETO_SALARIAL) {
            salarioInicial *= 1.02;
            c++;
        }
        return c;
    }

    public static int getMesesTetoSalario2(Funcionario f) {
        double salarioInicial = f.getSalario();
        int c = 0;
        do {

            salarioInicial *= 1.02;
            if (salarioInicial > TETO_SALARIAL) {
                salarioInicial = TETO_SALARIAL;
                break;
            }
            c++;
        } while (true);
        System.out.println(salarioInicial);
        return c;
    }

    public static void fazTraco(int colunas) {
        for (int i = 0; i <= colunas; i++) {
            System.out.print("-");
        }
        System.out.println("");
        {

        }

    }
}
