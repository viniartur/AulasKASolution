/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.kasolution.dominio;

import br.com.kasolution.util.Util;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.Date;



/**
 *
 * @author Admin
 */
public class Funcionario {

    private int codigo;
    private String nome;
    private String sobrenome;
    private Date dataAdmissao;
    private double salario;
    private String email;
    private static int ultimoCodigo = 0;
    private LocalDate dataNascimento;

    public Funcionario() {
    }

    public Funcionario(String nome, String sobrenome, double salario) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.salario = salario;
        this.dataAdmissao = new Date();// data do dia;
        this.email = nome.toLowerCase() + "." + sobrenome.toLowerCase()
                + "@kasolution.com.br";
        ultimoCodigo += 10;
        this.codigo = ++ultimoCodigo;
    }

    public Funcionario(String nome, String sobrenome) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        setSalario(salario);
        this.dataAdmissao = new Date();// data do dia;
        this.email = nome.toLowerCase() + "." + sobrenome.toLowerCase()
                + "@kasolution.com.br";
        this.codigo = ++ultimoCodigo;
    }
    // public Funcionario(String nome, String sobrenome){
    //   this(nome, sobrenome, 0.0);

    //}
    public String imprime() {
        String info = "Codigo: " + codigo + "\n";
        info += "Nome: " + nome + "\n";
        info += "sobrenome: " + sobrenome + "\n";
        info += "Dt.Adm.:" + DateFormat.getDateInstance().format(dataAdmissao) + "\n";
        info += "Salário: " + NumberFormat.getCurrencyInstance().format(salario) + "\n";
        info += "e-mail: " + email + "\n";
        info += "Dt.Nasc." + Util.fData(dataNascimento)+ "\n\n";
        return info;
    }

    public void setSalario(double salario) {
        if (salario >= 0) {
            this.salario = salario;
        } else {
            System.out.println("Salarios não pode ser negativo!");
            this.salario = 0.0;
        }

    }

    public double getSalario() {
        return salario;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public Date getDataAdmissao() {
        return dataAdmissao;
    }

    public String getEmail() {
        return email;
    }

    public static int getUltimoCodigo() {
        return ultimoCodigo;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

   
   
    
}
