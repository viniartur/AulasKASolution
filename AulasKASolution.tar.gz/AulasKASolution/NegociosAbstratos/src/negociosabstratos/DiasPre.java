/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package negociosabstratos;

/**
 *
 * @author Admin
 */
public enum DiasPre {
    TRINTA(30),
    SESSENTA(60),
    NOVENTA(90),
    CENTOEVINTE(120);
    
    private final int dias;
    
    private DiasPre(int dias) {
        this.dias = dias;
    }
    
    public int getDias() {
        return this.dias;
    }
}
