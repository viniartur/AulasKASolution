/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package negociosabstratos;

import java.text.NumberFormat;

/**
 *
 * @author Admin
 */
public class NegociosAbstratos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Cliente c1 = new Cliente();
        c1.adicionarAtivo(new ChequePre(200.00, DiasPre.TRINTA));
        c1.adicionarAtivo(new ChequePre(100.00, DiasPre.SESSENTA));
        
        ContaCorrente contaCorrente = new ContaCorrente(400.00,1000.00);
        contaCorrente.deposito(100.00);
        c1.adicionarAtivo(contaCorrente);
        
        Caixa caixa = new Caixa(200.00);
        caixa.deposito(700.00);
        c1.adicionarAtivo(caixa);
        
        System.out.println("Total dos Ativos " +
                NumberFormat.getCurrencyInstance()
                .format(Ativo.getAtivoTotal()));
        for (Object o : c1.getAtivos())         {
            System.out.println(o);
        }
                
    }
}
