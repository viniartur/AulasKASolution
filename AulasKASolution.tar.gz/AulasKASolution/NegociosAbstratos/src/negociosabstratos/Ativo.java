/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package negociosabstratos;

import java.text.NumberFormat;

/**
 *
 * @author Admin
 */
public abstract class Ativo {
    
    private static double ativoTotal;
    
    public Ativo(double valor) {
        this.ativoTotal += valor;
    }
    
    @Override
    public String toString() {
        return getDescricao() + " ativo acumulado " + 
                NumberFormat.getCurrencyInstance().format(
                getSaldoAcumulado());
    }
    
    public static double getAtivoTotal() {
        return ativoTotal;
    }
    
    public void deposito(double montante) {
        this.ativoTotal += montante;
    }
    
    public abstract double getValorAtivo();
    
    public abstract double getSaldoAcumulado();
    
    public abstract String getDescricao();
    
    public abstract void retirada(double montante);
    
}
