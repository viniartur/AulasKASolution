/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package negociosabstratos;

import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class Cliente {
    
    private ArrayList ativos = new ArrayList();
    
    public void adicionarAtivo(Ativo ativo) {
        ativos.add(ativo);
    }
    
    public ArrayList getAtivos() {
        return ativos;
    }
    
}
