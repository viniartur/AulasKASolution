/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package negociosabstratos;

import java.text.NumberFormat;

/**
 *
 * @author Admin
 */
public class Caixa extends Ativo {
    
    private static double saldoCompartilhadoCaixa;
    private double saldoCaixa;
    
    public Caixa(double valor) {
        super(valor); //acumula no ativoTotal
        this.saldoCaixa = valor;
        this.saldoCompartilhadoCaixa += valor;
    }

    @Override
    public double getValorAtivo() {
        return this.saldoCaixa;
    }

    @Override
    public double getSaldoAcumulado() {
        return this.saldoCompartilhadoCaixa;
    }

    @Override
    public String getDescricao() {
        return "Dinheiro em caixa " +
                NumberFormat.getCurrencyInstance()
                .format(getValorAtivo());
    }

    @Override
    public void retirada(double montante) {
        if (montante <= getSaldoAcumulado()) {
            System.out.println("O valor está disponível.");
        } else {
            System.out.println("O valor não está disponível.");
        }
    }
    
    @Override
    public void deposito(double montante) {
        //aumenta o valor do ativoTotal
        super.deposito(montante);
        //aumenta o valor compartilhado
        this.saldoCompartilhadoCaixa += montante;
        //aumenta o valor deste ativo
        this.saldoCaixa += montante;
    }
    
}
