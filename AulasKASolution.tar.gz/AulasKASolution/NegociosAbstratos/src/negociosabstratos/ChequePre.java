/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package negociosabstratos;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Admin
 */
public class ChequePre extends Ativo {
    
    private final Date dataPre;
    private static double saldoCompartilhadoCheque;
    private double valorCheque;
    private Calendar cal = Calendar.getInstance();
    
    public ChequePre(double valor, DiasPre diasPre) {
        super(valor); //soma no total de ativos
        cal.add(cal.DAY_OF_YEAR, diasPre.getDias());
        this.dataPre = cal.getTime();
        this.valorCheque = valor;
        this.saldoCompartilhadoCheque += valor;
    }

    @Override
    public double getValorAtivo() {
        return this.valorCheque;
    }

    @Override
    public double getSaldoAcumulado() {
        return this.saldoCompartilhadoCheque;
    }

    @Override
    public String getDescricao() {
        SimpleDateFormat dateFormat
                = new SimpleDateFormat("dd/MM/yyyy");
        return "Cheque Pré " +
                NumberFormat.getCurrencyInstance()
                .format(getValorAtivo()) +
                " para " +
                dateFormat.format(dataPre);
    }

    @Override
    public void retirada(double montante) {
        Date hoje = new Date();
        if (hoje.after(dataPre) && montante
                == getValorAtivo()) {
            System.out.println("O cheque está disponível"
                    + " para retirada");
        } else {
            System.out.println("Cheque indisponível"
                    + " para retirada");
        }
    }
    
    @Override
    public void deposito(double montante) {
        System.out.println("Não é possivel adicionar"
                + " valor a cheques");
    }
    
}
