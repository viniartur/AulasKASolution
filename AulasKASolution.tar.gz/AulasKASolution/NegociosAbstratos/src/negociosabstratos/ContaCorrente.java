/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package negociosabstratos;

import java.text.NumberFormat;

/**
 *
 * @author Admin
 */
public class ContaCorrente extends Ativo {
    
    private static double saldoCompartilhadoCorrente;
    private final double limiteEspecial;
    private double saldoContaCorrente;
    
    public ContaCorrente(double saldo, double limiteEspecial) {
        super(saldo + limiteEspecial); //passa o valor para o ativoTotal (pai)
        this.limiteEspecial = limiteEspecial;
        this.saldoContaCorrente = saldo;
        this.saldoCompartilhadoCorrente += saldo + limiteEspecial;
    }
    
    public double getLimiteEspecial() {
        return this.limiteEspecial;
    }

    @Override
    public double getValorAtivo() {
        return this.saldoContaCorrente + limiteEspecial;
    }

    @Override
    public double getSaldoAcumulado() {
        return this.saldoCompartilhadoCorrente;
    }

    @Override
    public String getDescricao() {
        return "Saldo C.Conrrente " +
                NumberFormat.getCurrencyInstance()
                .format(getValorAtivo()) +
                " limite especial " +
                NumberFormat.getCurrencyInstance()
                .format(getLimiteEspecial());                
        
    }

    @Override
    public void retirada(double montante) {
        if (montante <= getSaldoAcumulado()) {
            System.out.println("A retirada é possivel");
        } else {
            System.out.println("A retirada não é possivel");
        }
    }
    
    @Override
    public void deposito(double montante) {
        //aumenta no total de ativos
        super.deposito(montante);
        //aumenta o saldo desse ativo
        this.saldoContaCorrente += montante;
        //aumenta o saldo da categoria
        this.saldoCompartilhadoCorrente += montante;
    }
    
}
