
package br.com.kasolution.dominio;


public class Aluno {
    
    public int codigo;
    public String nome;
    
    public void escreveAluno(){
        System.out.println(codigo);
        System.out.println(nome);
        
    }
}
