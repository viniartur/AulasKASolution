
package br.com.kasolution.dominio;


public class Curso {
    public int codigo;
    public String nome;
    public double valor;
    public String dataInicio;
    public String dataFim;
    
    public void imprimiInfo(){
        System.out.println("Curso: "+ codigo);
        System.out.println("Nome: " + nome);
        System.out.println("Valor: "+ valor);
        System.out.println("Inicio/Fim: "+ dataInicio+"---"+dataFim);
    }
    
}
