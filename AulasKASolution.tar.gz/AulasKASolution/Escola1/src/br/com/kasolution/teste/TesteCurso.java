
package br.com.kasolution.teste;

import br.com.kasolution.dominio.Curso;


public class TesteCurso {

    
    public static void main(String[] args) {
        
       Curso curso1; //declaração da variavel
       curso1 = new Curso();
       Curso curso2 = new Curso(); //declara instancia na mesma linha 
       //manipulação do obSto
       curso1.codigo =97110;
       curso1.nome= "Java Modulo I";
       curso1.valor = 3000.00;
       curso1.dataInicio ="30/10/2018";
       curso1.dataFim = "06/12/2018";
       curso1.imprimiInfo();
       
        System.out.println("");
        
       curso2.codigo =97275;  
       curso2.nome = "Java Modulo II";
       curso2.valor = 300.00;
       curso2.dataInicio = "08/01/2019";
       curso2.dataFim = "10/02/2019";
       
       curso2.imprimiInfo();
    }
}
