package br.com.kasolution.teste;

import br.com.kasolution.dominio.Aluno;

public class TesteAluno {

    public static void main(String[] args) {
        Aluno aluno1 = new Aluno();
        Aluno aluno2 = new Aluno();

        aluno1.codigo = 1;
        aluno1.nome = "fulano";
        
        aluno2.codigo =2;
        aluno2.nome = "ciclano";
        
        aluno1.escreveAluno();
        aluno2.escreveAluno();
       
                
        
                
    
    }
}
