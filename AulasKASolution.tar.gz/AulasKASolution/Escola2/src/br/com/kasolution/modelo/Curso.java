package br.com.kasolution.modelo;

import br.com.kasolution.util.Formata;
import java.util.Calendar;

public class Curso {
    public int codigo;
    public String nome;
    public Calendar dataInicio;
    public Calendar dataFim;
    public Aluno[] alunos;
    
    public Curso(){
        
    }
    
    public Curso(int codigo, String nome, Calendar dataInicio) {
        this.codigo = codigo;        
        this.nome = nome;
        this.dataInicio = dataInicio;
        this.dataFim = Calendar.getInstance();
        //acrescenta 30 dias no fim
        this.dataFim.add(Calendar.DAY_OF_MONTH, 30);
    }
    
    public void imprimir() {
        System.out.println("Aluno: " + codigo);
        System.out.println("Nome: " + nome);
        //Formata f = new Formata();//CTRL+SHIFT+I
        System.out.println("Inicio: " + Formata.data(dataInicio.getTime()));
        System.out.println("Fim: " + Formata.data(dataFim.getTime()));
    }
}
