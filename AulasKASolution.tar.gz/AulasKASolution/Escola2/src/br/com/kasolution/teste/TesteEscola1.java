package br.com.kasolution.teste;

import br.com.kasolution.modelo.Curso;
import java.util.Calendar;

public class TesteEscola1 {

    public static void main(String[] args) {
        Curso curso = new Curso(97110, "Java", Calendar.getInstance());
        curso.imprimir();
    }
}
