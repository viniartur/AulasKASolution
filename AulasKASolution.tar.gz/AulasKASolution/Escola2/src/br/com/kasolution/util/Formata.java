package br.com.kasolution.util;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;

public class Formata {
    
    public static String data(Date date) {
        return DateFormat.getDateInstance().format(date);
    }
    public static String num (double d) {
        return NumberFormat.getNumberInstance().format(d);
    }
}
