/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.domain;

/**
 *
 * @author Admin
 */
public class Engineer extends Employee {
    public Engineer(int iD, String name,
            String sSN, double salary){
        super(iD, name, sSN, salary);
    }
}
