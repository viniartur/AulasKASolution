/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.domain;

import java.text.NumberFormat;

/**
 *
 * @author Admin
 */
public class Employee {

    private int iD;
    private String name;
    private String sSN; //Social Security Number
    private double salary;

    public Employee(int iD, String name, String sSN,
            double salary) {
        this.iD = iD;
        this.name = name;
        this.sSN = sSN;
        this.salary = salary;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void raiseSalary(double increase) {
        this.salary += increase;
    }

    public int getiD() {
        return iD;
    }

    public String getName() {
        return name;
    }

    public String getsSN() {
        return sSN;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "\nEmployee ID: " + getiD()
                + "\nEmployee Name: " + getName()
                + "\nEmployee SSN #: " + getsSN()
                + "\nEmployee Salary: "
                + NumberFormat.getCurrencyInstance().format(getSalary());
    }
}
