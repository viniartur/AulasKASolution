/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.domain;

/**
 *
 * @author Admin
 */
public class Manager extends Employee {

    private String deptName;
    private Employee[] staff;
    private int employeeCount = 0;

    public Manager(int iD, String name, String sSN,
            double salary, String deptName) {
        super(iD, name, sSN, salary);
        this.deptName = deptName;
        staff = new Employee[20];
    }

    public String getDeptName() {
        return this.deptName;
    }

    public int findEmployee(Employee e) {
        for (int i = 0; i < employeeCount; i++) {
            if (staff[i].getiD() == e.getiD()) {
                return i;
            }
        }
        return -1;
    }

    public boolean addEmployee(Employee e) {
        if (findEmployee(e) == -1
                && employeeCount < 20) {
            staff[employeeCount++] = e;
            return true;
        } else {
            return false;
        }
    }

    public boolean removeEmployee(Employee e) {
        int pos = findEmployee(e);
        if (pos == -1) {
            return false;
        } else {
            int tempCount = 0;
            Employee[] tempStaff = new Employee[20];
            for (int i = 0; i < employeeCount; i++) {
                if (i != pos) {
                    tempStaff[tempCount++] = staff[i];
                }
            }
            staff = tempStaff;
            employeeCount = tempCount;
            return true;
        }
    }

    public void printStaffDetails() {
        System.out.println("\nManager: " + getName());
        for (int i = 0; i < employeeCount; i++) {
            System.out.println("\tStaff - "
                    + i + ": " + staff[i].getName());
        }
    }
    
    @Override
    public String toString() {
        return super.toString() + "\nDepartment: " + getDeptName();
    }
}
